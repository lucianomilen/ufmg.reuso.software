package br.ufmg.reuso.ui;

public class ScreenControl {
	public static String nomeProjeto = "padrao";

}
