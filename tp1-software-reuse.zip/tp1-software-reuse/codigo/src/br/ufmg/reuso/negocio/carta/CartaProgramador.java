package br.ufmg.reuso.negocio.carta;

public class CartaProgramador extends Carta {

	public CartaProgramador(String titulo, String codigo, String texto, int tipo) {
		super(titulo, codigo, texto, tipo);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void mostrarCarta() {
		// TODO Auto-generated method stub

	}

}
