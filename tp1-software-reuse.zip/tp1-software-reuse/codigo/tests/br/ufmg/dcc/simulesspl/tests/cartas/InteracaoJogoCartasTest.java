/**
 * 
 */
package br.ufmg.dcc.simulesspl.tests.cartas;

import static org.junit.Assert.assertEquals;

import java.util.Random;

import interfaces.SetupInteraction;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import screenControllers.ScreenInteraction;

import jogo.Jogo;
import junit.framework.TestCase;

/**
 * @author alcemir
 *
 */
public class InteracaoJogoCartasTest extends TestCase {

	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void testFormarBaralhoCarta(){}
	
	@Test
	public void testTrocarBaralhoCartas(){}
	
	@Test
	public void testRetirarCartas(){}
	
	@After
	public void tearDown() throws Exception {
		
	}
}
