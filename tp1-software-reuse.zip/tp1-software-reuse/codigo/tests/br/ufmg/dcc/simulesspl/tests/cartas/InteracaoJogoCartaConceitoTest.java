/**
 * 
 */
package br.ufmg.dcc.simulesspl.tests.cartas;

import org.junit.Test;

import junit.framework.TestCase;

/**
 * @author alcemir
 *
 */
public class InteracaoJogoCartaConceitoTest extends TestCase {

	@Test
	public void testUsarConceito(){}
}
